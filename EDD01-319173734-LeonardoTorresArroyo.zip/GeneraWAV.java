package generaWav;

import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author USUARIO
 */
public class GeneraWAV {

    public void escribe(String nombre, int iTiempo, int iFrecuenciaMuestreo, int iArmonico) {
        if (iTiempo < 0) {
            throw new java.lang.IllegalArgumentException();
        }
        if (iFrecuenciaMuestreo < 0) {
            throw new java.lang.IllegalArgumentException();
        }
        if (iArmonico < 0) {
            throw new java.lang.IllegalArgumentException();
        }
        String ultimo = nombre.substring(nombre.length() - 4);
        if (!".wav".equals(ultimo)) {
            throw new java.lang.IllegalArgumentException();
        }

        DataOutputStream as;
        char a, b, c, d, e2, f, g, h;
        int tamano, aux, byteS, bytes_arch;
        int nMuestras;
        int formato = 16;
        short pcm = 1;
        short canal = 1;
        short bytes_m = 2;
        short bits_m = 16;
        byte j[];
        int contador;
        int muestra;
        double aux2;
        try {
            GeneraWAV conv = new GeneraWAV();
            as = new DataOutputStream(new FileOutputStream(nombre));

            //Escribe la constante RIFF en big
            a = 'R';
            b = 'I';
            c = 'F';
            d = 'F';
            as.write(a);
            as.write(b);
            as.write(c);
            as.write(d);

            //Calcula el numero de muestras
            nMuestras = iTiempo * iFrecuenciaMuestreo;

            //Escribe el tamaño del archivo en little
            tamano = (iFrecuenciaMuestreo * iTiempo * bytes_m) + 36;
            j = conv.intArregloByte(tamano, false);
            for (contador = 0; contador < 4; contador++) {
                as.writeByte(j[contador]);
            }

            //Escribe la constante wave big
            a = 'W';
            b = 'A';
            c = 'V';
            d = 'E';
            e2 = 'f';
            f = 'm';
            g = 't';
            h = ' ';
            as.write(a);
            as.write(b);
            as.write(c);
            as.write(d);
            as.write(e2);
            as.write(f);
            as.write(g);
            as.write(h);

            //Escribe la constante 16 en little
            j = conv.intArregloByte(formato, false);
            for (contador = 0; contador < 4; contador++) {
                as.writeByte(j[contador]);
            }

            //Escribe pcm en little
            j = conv.shortArregloByte(pcm, false);
            for (contador = 0; contador < 2; contador++) {
                as.writeByte(j[contador]);
            }

            //Escribe el numero de canales en little
            j = conv.shortArregloByte(canal, false);
            for (contador = 0; contador < 2; contador++) {
                as.writeByte(j[contador]);
            }

            //Escribe la frecuencia de muestro en little
            aux = iFrecuenciaMuestreo;
            j = conv.intArregloByte(aux, false);
            for (contador = 0; contador < 4; contador++) {
                as.writeByte(j[contador]);
            }

            //Escribe el numero de bytes por segundo en little
            byteS = iFrecuenciaMuestreo * 2;
            j = conv.intArregloByte(byteS, false);
            for (contador = 0; contador < 4; contador++) {
                as.writeByte(j[contador]);
            }

            //Escribe el numero de bytes por muestra en little
            aux = bytes_m;
            j = conv.shortArregloByte((short) aux, false);
            for (contador = 0; contador < 2; contador++) {
                as.writeByte(j[contador]);
            }

            //Escribe el numero de bits por muestra en little
            j = conv.shortArregloByte(bits_m, false);
            for (contador = 0; contador < 2; contador++) {
                as.writeByte(j[contador]);
            }

            //Escribe la palabra data en big
            a = 'd';
            b = 'a';
            c = 't';
            d = 'a';
            as.write(a);
            as.write(b);
            as.write(c);
            as.write(d);

            //Numero de bytes que ocupan las muestras
            bytes_arch = nMuestras * bytes_m;
            j = conv.intArregloByte(bytes_arch, false);
            for (contador = 0; contador < 4; contador++) {
                as.writeByte(j[contador]);
            }

            //Numero de muestra
            for (int i = 0; i <= iFrecuenciaMuestreo; i++) {
                aux2 = Math.sin((((2 * Math.PI) / iFrecuenciaMuestreo) * iArmonico) * i);
                muestra = (int) (32000 * aux2);
                j = conv.intArregloByte(muestra, false);
                for (contador = 0; contador < 4; contador++) {
                    as.write(j[contador]);
                }
            }

        } catch (IOException e) {

        }
    }

    private byte[] intArregloByte(int valor, boolean bigEndian) {
        byte[] resultado;
        byte b3 = (byte) ((valor >> 24) & 0xFF);
        byte b2 = (byte) ((valor >> 16) & 0xFF);
        byte b1 = (byte) ((valor >> 8) & 0xFF);
        byte b0 = (byte) (valor & 0xFF);
        if (bigEndian) {
            resultado = new byte[]{b3, b2, b1, b0};
        } else {
            resultado = new byte[]{b0, b1, b2, b3};
        }
        return resultado;
    }

    private byte[] shortArregloByte(short valor, boolean bigEndian) {
        byte[] resultado;
        byte b1 = (byte) ((valor >> 8) & 0xFF);
        byte b0 = (byte) (valor & 0xFF);
        if (bigEndian) {
            resultado = new byte[]{b1, b0};
        } else {
            resultado = new byte[]{b0, b1};
        }
        return resultado;
    }
}
