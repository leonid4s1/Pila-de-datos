package generaWav;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USUARIO
 */
public class EjecutaWAV {

    public static void main(String[] args) {
        String nombreArch, frecuM, frecu, time;
        int fm, fr, tim;
        RandomAccessFile arch;
        try {
            arch = new RandomAccessFile(args[0], "r");

            nombreArch = arch.readLine();

            frecuM = arch.readLine();
            fm = Integer.valueOf(frecuM);

            frecu = arch.readLine();
            fr = Integer.valueOf(frecu);

            time = arch.readLine();
            tim = Integer.valueOf(time);

            GeneraWAV ejercicio = new GeneraWAV();
            ejercicio.escribe(nombreArch, tim, fm, fr);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(EjecutaWAV.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EjecutaWAV.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
